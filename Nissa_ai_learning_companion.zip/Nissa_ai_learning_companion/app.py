import streamlit as st
import sys, os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


st.set_page_config(
    page_title="AI Learning Companion",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded"
)


from utils.styling import apply_styling
apply_styling()

# ===== SIDEBAR =====
with st.sidebar:
    st.markdown('<p class="main-title" style="font-size:1.6rem; color:#fdf6ec !important; -webkit-text-fill-color:#fdf6ec !important;">🎓 LearnAI</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title" style="color:#d7ccc8 !important;">Your Smart Learning Companion</p>', unsafe_allow_html=True)
    st.divider()

    dark_mode = st.toggle("🌙 Dark Mode", value=False)

    menu = st.radio(
        "Navigate",
        ["🏠 Home", "💬 Ask Anything", "📅 Study Plan", "📝 Quiz Generator",
         "📚 RAG Assistant", "ℹ️ About", "🃏 Flashcard", "📊 Progress"],
        label_visibility="collapsed"
    )

    st.divider()
    st.markdown("### ⚙️ Settings")
    api_choice = st.selectbox("AI Provider", ["Gemini", "OpenAI"])

    if api_choice == "Gemini":
        api_key = st.text_input("Gemini API Key", type="password", placeholder="AIza...", key="gemini_key")
        if api_key:
            st.session_state["gemini_api_key"] = api_key
            st.success("✅ Gemini connected")
    else:
        api_key = st.text_input("OpenAI API Key", type="password", placeholder="sk-...", key="openai_key")
        if api_key:
            st.session_state["openai_api_key"] = api_key
            st.success("✅ OpenAI connected")

    st.session_state["api_provider"] = api_choice

# ===== DARK MODE =====
if dark_mode:
    st.markdown("""
    <style>
        .stApp { 
            background: linear-gradient(135deg, #1a0f0a 0%, #2d1b12 50%, #3b2314 100%) !important; 
        }
        p, span, div, label { color: #f5e6d3 !important; }
        h1 {
            background: linear-gradient(135deg, #d7a87a, #c49a6c, #f5deb3) !important;
            -webkit-background-clip: text !important;
            -webkit-text-fill-color: transparent !important;
        }
        h2, h3 { color: #e8c99a !important; -webkit-text-fill-color: #e8c99a !important; }
        .stTextInput > div > div > input,
        .stTextArea textarea {
            background: rgba(60, 30, 15, 0.8) !important;
            color: #f5e6d3 !important;
            border-color: #8d6e63 !important;
        }
        .stSelectbox > div > div {
            background: rgba(60, 30, 15, 0.8) !important;
            color: #f5e6d3 !important;
        }
        [data-testid="stChatMessage"] {
            background: rgba(50, 25, 10, 0.85) !important;
        }
    </style>
    """, unsafe_allow_html=True)

# ===== PAGE ROUTING =====
if "🏠 Home" in menu:
    from views.home import show
    show()
elif "💬 Ask Anything" in menu:
    from views.qa import show
    show()
elif "📅 Study Plan" in menu:
    from views.study_plan import show
    show()
elif "📝 Quiz Generator" in menu:
    from views.quiz import show
    show()
elif "📚 RAG Assistant" in menu:
    from views.rag import show
    show()
elif "ℹ️ About" in menu:
    from views.about import show
    show()
elif "🃏 Flashcard" in menu:
    from views.flashcard import show
    show()
elif "📊 Progress" in menu:
    from views.progress import show
    show()