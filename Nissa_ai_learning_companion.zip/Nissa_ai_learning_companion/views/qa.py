import streamlit as st
import sys, os
import base64
from gtts import gTTS
import io
from utils.styling import apply_styling

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.ai_helper import get_ai_response, check_api_configured

SYSTEM_PROMPT = """Kamu adalah tutor AI yang cerdas dan ramah. Tugasmu adalah menjawab pertanyaan siswa 
dengan cara yang jelas, terstruktur, dan mudah dipahami. 

Gunakan format berikut saat menjawab:
- Mulai dengan penjelasan singkat (1-2 kalimat)
- Gunakan bullet points untuk poin-poin penting
- Sertakan contoh konkret jika relevan
- Akhiri dengan rangkuman singkat jika topiknya kompleks

Jika ada gambar yang diberikan, analisis gambar tersebut dan jawab pertanyaan terkait gambar.
Jika ada file teks/dokumen, baca kontennya dan bantu siswa memahaminya.
Jawab dalam bahasa yang sama dengan pertanyaan (Indonesia atau Inggris).
"""

def text_to_speech(text):
    """Convert text to speech and return base64 audio"""
    # Bersihkan markdown agar tidak ikut dibacakan
    import re
    clean = re.sub(r'[#*`_~>\[\]()]', '', text)
    clean = re.sub(r'\n+', '. ', clean)
    clean = clean.strip()
    tts = gTTS(text=clean[:3000], lang='id')  # batasi 3000 char
    buf = io.BytesIO()
    tts.write_to_fp(buf)
    buf.seek(0)
    audio_b64 = base64.b64encode(buf.read()).decode()
    return audio_b64

def render_audio_player(audio_b64, key_id, autoplay=True):
    """Render audio player dengan tombol pause/stop dan autoplay opsional"""
    autoplay_attr = "autoplay" if autoplay else ""
    st.markdown(f"""
    <div style="
        background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
        border: 1px solid #c8a97a;
        border-radius: 12px;
        padding: 0.8rem 1.2rem;
        margin-top: 0.8rem;
        display: flex;
        align-items: center;
        gap: 0.8rem;
    ">
        <span style="font-size:1.3rem;">🔊</span>
        <div style="flex:1;">
            <p style="margin:0 0 0.3rem 0; color:#3e2723; font-weight:600; font-size:0.85rem;">
                AI sedang membacakan jawaban...
            </p>
            <audio id="audio_{key_id}" {autoplay_attr} controls style="
                width: 100%;
                height: 36px;
                border-radius: 8px;
                accent-color: #6d4c41;
            ">
                <source src="data:audio/mp3;base64,{audio_b64}" type="audio/mp3">
            </audio>
        </div>
    </div>

    <script>
        // Auto-stop audio lain jika ada yang sedang main
        const currentAudio = document.getElementById('audio_{key_id}');
        if (currentAudio) {{
            document.querySelectorAll('audio').forEach(a => {{
                if (a.id !== 'audio_{key_id}') {{
                    a.pause();
                    a.currentTime = 0;
                }}
            }});
        }}
    </script>
    """, unsafe_allow_html=True)

def process_uploaded_file(uploaded_file):
    """Process uploaded file and return content for AI"""
    file_type = uploaded_file.type
    file_name = uploaded_file.name

    if file_type.startswith("image/"):
        img_bytes = uploaded_file.read()
        img_b64 = base64.b64encode(img_bytes).decode()
        return {"type": "image", "data": img_b64, "mime": file_type, "name": file_name}
    elif file_type == "text/plain":
        content = uploaded_file.read().decode("utf-8")
        return {"type": "text", "data": content, "name": file_name}
    elif file_type == "application/pdf":
        pdf_bytes = uploaded_file.read()
        pdf_b64 = base64.b64encode(pdf_bytes).decode()
        return {"type": "pdf", "data": pdf_b64, "name": file_name}
    else:
        return {"type": "unknown", "name": file_name}

def show():
    apply_styling()

    st.markdown('<h2 style="font-family:Playfair Display,serif; background:linear-gradient(135deg,#3e2723,#8d6e63); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">💬 Ask Anything</h2>', unsafe_allow_html=True)
    st.markdown('<p style="color:#6d4c41; font-size:1rem; margin-bottom:1.5rem;">Tanyakan apapun tentang pelajaran — AI siap membantu!</p>', unsafe_allow_html=True)

    if not check_api_configured():
        st.warning("⚠️ Harap masukkan API Key di sidebar terlebih dahulu.")
        return

    if "qa_messages" not in st.session_state:
        st.session_state.qa_messages = []

    # Toggle auto-TTS di sidebar
    with st.sidebar:
        st.markdown("---")
        st.markdown("### 🔊 Pengaturan Suara")
        auto_tts = st.toggle("🤖 AI Otomatis Bicara", value=True, 
                              help="Aktifkan agar AI langsung membacakan jawaban setelah menjawab")
        tts_lang = st.selectbox("🌐 Bahasa Suara", 
                                 ["Indonesia (id)", "English (en)"],
                                 index=0)
        lang_code = "id" if "id" in tts_lang else "en"

    subject = st.selectbox(
        "📚 Pilih Mata Pelajaran (opsional)",
        ["Umum", "Matematika", "Fisika", "Kimia", "Biologi", "Sejarah",
         "Bahasa Indonesia", "Bahasa Inggris", "Pemrograman", "Ekonomi", "Lainnya"]
    )

    # ===== CONTOH PERTANYAAN =====
    st.markdown('<p style="color:#4e342e; font-weight:700; margin-bottom:0.5rem;">💡 Contoh pertanyaan:</p>', unsafe_allow_html=True)
    examples = [
        "Jelaskan apa itu integral dan berikan contohnya",
        "Apa perbedaan mitosis dan meiosis?",
        "Bagaimana cara kerja algoritma sorting bubble sort?",
        "Jelaskan hukum Newton 1, 2, dan 3",
        "Apa itu fotosintesis dan di mana prosesnya terjadi?",
    ]
    cols = st.columns(3)
    for i, ex in enumerate(examples[:3]):
        with cols[i]:
            if st.button(ex[:35] + "...", key=f"ex_{i}", use_container_width=True):
                st.session_state["example_question"] = ex
                st.rerun()

    if "example_question" in st.session_state:
        user_input = st.session_state.pop("example_question")
        st.session_state.qa_messages.append({"role": "user", "content": user_input})
        with st.chat_message("user", avatar="🧑‍🎓"):
            st.markdown(user_input)
        context = f"Mata pelajaran: {subject}\n\n" if subject != "Umum" else ""
        full_prompt = f"{context}Pertanyaan: {user_input}"
        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("🧠 AI sedang memproses..."):
                response = get_ai_response(full_prompt, SYSTEM_PROMPT)
            st.markdown(response)
            # Auto TTS
            audio_b64 = text_to_speech(response)
            render_audio_player(audio_b64, key_id=f"ex_{len(st.session_state.qa_messages)}", autoplay=auto_tts)
        st.session_state.qa_messages.append({"role": "assistant", "content": response})

    st.markdown("---")

    # ===== UPLOAD & VOICE SECTION =====
    st.markdown("""
    <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                border-left: 5px solid #8d6e63;
                border-radius: 12px;
                padding: 1rem 1.5rem;
                margin-bottom: 1rem;">
        <p style="color:#3e2723; font-weight:700; margin:0 0 0.5rem 0;">📎 Lampirkan Materi atau Rekam Pertanyaan</p>
        <p style="color:#6d4c41; font-size:0.85rem; margin:0;">Upload foto soal, file materi, atau rekam pertanyaanmu lewat suara!</p>
    </div>
    """, unsafe_allow_html=True)

    tab1, tab2, tab3 = st.tabs(["🖼️ Upload Foto/Gambar", "📄 Upload File", "🎙️ Voice Note"])

    uploaded_image = None

    with tab1:
        st.markdown('<p style="color:#4e342e; font-size:0.9rem;">Upload foto soal atau gambar materi yang ingin ditanyakan.</p>', unsafe_allow_html=True)
        uploaded_image = st.file_uploader(
            "Pilih gambar",
            type=["jpg", "jpeg", "png", "webp", "gif"],
            key="img_uploader",
            label_visibility="collapsed"
        )
        if uploaded_image:
            st.image(uploaded_image, caption=f"📷 {uploaded_image.name}", use_column_width=True)
            st.success(f"✅ Gambar **{uploaded_image.name}** siap dikirim!")
            st.markdown('<p style="color:#6d4c41; font-size:0.85rem;">💬 Ketik pertanyaanmu di kotak chat di bawah.</p>', unsafe_allow_html=True)

    with tab2:
        st.markdown('<p style="color:#4e342e; font-size:0.9rem;">Upload file teks atau PDF berisi materi yang ingin dibahas.</p>', unsafe_allow_html=True)
        uploaded_doc = st.file_uploader(
            "Pilih file",
            type=["txt", "pdf"],
            key="doc_uploader",
            label_visibility="collapsed"
        )
        if uploaded_doc:
            file_info = process_uploaded_file(uploaded_doc)
            st.session_state["uploaded_file_info"] = file_info
            if file_info["type"] == "text":
                st.success(f"✅ File **{uploaded_doc.name}** berhasil dibaca!")
                with st.expander("👁️ Preview isi file"):
                    preview = file_info["data"][:1000]
                    st.text(preview + ("..." if len(file_info["data"]) > 1000 else ""))
            elif file_info["type"] == "pdf":
                st.success(f"✅ PDF **{uploaded_doc.name}** siap dikirim!")
                st.info("📌 AI akan membantu menganalisis isi PDF ini.")
            st.markdown('<p style="color:#6d4c41; font-size:0.85rem;">💬 Ketik pertanyaanmu di kotak chat di bawah.</p>', unsafe_allow_html=True)

    with tab3:
        st.markdown('<p style="color:#4e342e; font-size:0.9rem;">Rekam pertanyaanmu menggunakan mikrofon.</p>', unsafe_allow_html=True)
        audio_value = st.audio_input("🎙️ Klik untuk merekam pertanyaanmu")
        if audio_value:
            st.success("✅ Rekaman berhasil!")
            st.audio(audio_value, format="audio/wav")
            audio_bytes = audio_value.read()
            audio_b64 = base64.b64encode(audio_bytes).decode()
            st.session_state["voice_audio_b64"] = audio_b64
            st.markdown("""
            <div style="background:rgba(141,110,99,0.1); border-radius:10px; padding:0.8rem; text-align:center; color:#4e342e; font-size:0.85rem;">
                🎙️ <strong>Voice note terekam!</strong><br>Ketik ringkasan pertanyaanmu di chat agar AI bisa menjawab lebih akurat.
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")

    # ===== CHAT HISTORY =====
    chat_container = st.container()
    with chat_container:
        if not st.session_state.qa_messages:
            st.markdown("""
            <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                        border-left: 5px solid #8d6e63;
                        border-radius: 12px;
                        padding: 1rem 1.5rem;
                        margin: 1rem 0;">
                <span style="color:#4e342e; font-size:0.95rem;">
                💡 <strong style="color:#3e2723;">Tips:</strong> Kamu bisa bertanya tentang konsep, minta penjelasan, 
                atau meminta contoh soal. Contoh: <em>"Jelaskan apa itu integral?"</em>
                </span>
            </div>
            """, unsafe_allow_html=True)
        else:
            for msg in st.session_state.qa_messages:
                with st.chat_message(msg["role"], avatar="🧑‍🎓" if msg["role"] == "user" else "🤖"):
                    if "image" in msg:
                        st.image(f"data:{msg['image_mime']};base64,{msg['image']}",
                                caption="📷 Gambar yang dikirim", use_column_width=True)
                    if "file_preview" in msg:
                        with st.expander("📄 File yang dikirim"):
                            st.text(msg["file_preview"])
                    st.markdown(msg["content"])

    # ===== CHAT INPUT =====
    user_input = st.chat_input("Ketik pertanyaanmu di sini...")

    if user_input:
        context = f"Mata pelajaran: {subject}\n\n" if subject != "Umum" else ""
        extra_context = ""
        msg_data = {"role": "user", "content": user_input}

        if uploaded_image:
            uploaded_image.seek(0)
            file_info = process_uploaded_file(uploaded_image)
            msg_data["image"] = file_info["data"]
            msg_data["image_mime"] = file_info["mime"]
            extra_context += f"\n[Siswa mengirim gambar: {uploaded_image.name}. Analisis dan bantu menjawab.]\n"

        if "uploaded_file_info" in st.session_state:
            file_info = st.session_state["uploaded_file_info"]
            if file_info["type"] == "text":
                preview = file_info["data"][:3000]
                extra_context += f"\n[File teks '{file_info['name']}':\n{preview}]\n"
                msg_data["file_preview"] = preview[:200] + "..."
            elif file_info["type"] == "pdf":
                extra_context += f"\n[PDF '{file_info['name']}' dikirim siswa.]\n"

        if "voice_audio_b64" in st.session_state:
            extra_context += "\n[Siswa juga mengirim voice note.]\n"

        full_prompt = f"{context}{extra_context}Pertanyaan: {user_input}"
        st.session_state.qa_messages.append(msg_data)

        with st.chat_message("user", avatar="🧑‍🎓"):
            if "image" in msg_data:
                st.image(f"data:{msg_data['image_mime']};base64,{msg_data['image']}",
                        caption="📷 Gambar yang dikirim", use_column_width=True)
            if "file_preview" in msg_data:
                with st.expander("📄 File yang dikirim"):
                    st.text(msg_data["file_preview"])
            st.markdown(user_input)

        with st.chat_message("assistant", avatar="🤖"):
            with st.spinner("🧠 AI sedang berpikir..."):
                response = get_ai_response(full_prompt, SYSTEM_PROMPT)
            st.markdown(response)

            # ✅ AUTO TTS — langsung berbunyi + ada player dengan tombol pause/stop
            with st.spinner("🔊 Menyiapkan suara..."):
                audio_b64 = text_to_speech(response)
            render_audio_player(
                audio_b64, 
                key_id=f"chat_{len(st.session_state.qa_messages)}", 
                autoplay=auto_tts
            )

        st.session_state.qa_messages.append({"role": "assistant", "content": response})

        if "uploaded_file_info" in st.session_state:
            del st.session_state["uploaded_file_info"]
        if "voice_audio_b64" in st.session_state:
            del st.session_state["voice_audio_b64"]

    # ===== CLEAR CHAT =====
    if st.session_state.qa_messages:
        st.markdown("---")
        col1, col2, col3 = st.columns([1, 1, 1])
        with col2:
            if st.button("🗑️ Hapus Riwayat Chat"):
                st.session_state.qa_messages = []
                st.rerun()

        chat_text = "\n\n".join([
            f"{'Kamu' if m['role'] == 'user' else 'AI'}: {m['content']}"
            for m in st.session_state.qa_messages
        ])
        st.download_button(
            label="💾 Export Chat (.txt)",
            data=chat_text,
            file_name="riwayat_chat.txt",
            mime="text/plain"
        )