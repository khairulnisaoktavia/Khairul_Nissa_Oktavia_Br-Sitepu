import streamlit as st
from utils.styling import apply_styling

def show():
    apply_styling()

    st.markdown('<h2 style="font-family:Playfair Display,serif; background:linear-gradient(135deg,#3e2723,#8d6e63); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">👥 About This Project</h2>', unsafe_allow_html=True)
    st.markdown('<p style="color:#6d4c41; font-size:1rem; margin-bottom:1.5rem;">AI-Powered Smart Learning Companion for Personalized Education</p>', unsafe_allow_html=True)
    st.markdown("---")

    # ===== PROJECT INFO =====
    st.markdown("""
    <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                border: 1px solid #d7ccc8;
                border-left: 5px solid #8d6e63;
                border-radius: 16px;
                padding: 2rem;
                margin-bottom: 1.5rem;
                box-shadow: 0 4px 15px rgba(93,64,55,0.1);">
        <h3 style="color:#3e2723; margin:0 0 1rem 0; font-family:Playfair Display,serif;">📋 Informasi Project</h3>
        <table style="width:100%; font-size:0.95rem;">
            <tr><td style="padding:8px 0; color:#6d4c41; width:160px;">Nama Project</td>
                <td style="padding:8px 0; color:#3e2723;"><strong>AI Learning Companion</strong></td></tr>
            <tr><td style="padding:8px 0; color:#6d4c41;">Name</td>
                <td style="padding:8px 0; color:#3e2723;"><strong>Khairul Nissa Oktavia Br Sitepu</strong></td></tr>
            <tr><td style="padding:8px 0; color:#6d4c41;">Bidang</td>
                <td style="padding:8px 0; color:#3e2723;"><strong>Education Technology (EdTech)</strong></td></tr>
            <tr><td style="padding:8px 0; color:#6d4c41;">Durasi</td>
                <td style="padding:8px 0; color:#3e2723;"><strong>6 Minggu</strong></td></tr>
        </table>
    </div>
    """, unsafe_allow_html=True)

    # ===== ANGGOTA KELOMPOK =====
    st.markdown('<h3 style="color:#4e342e; font-family:Playfair Display,serif;">👨‍💻 Anggota Kelompok</h3>', unsafe_allow_html=True)
    members = [
        {"name": "Khairul Nisaa Oktavia Br Sitepu", "role": "Team Leader", "skills": "Python, AI, Streamlit"},
        {"name": "Anggota 2", "role": "Developer", "skills": "API Integration, UI Design"},
        {"name": "Anggota 3", "role": "Developer", "skills": "RAG, Vector Database"},
    ]
    cols = st.columns(len(members))
    for i, m in enumerate(members):
        with cols[i]:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                        border: 1px solid #d7ccc8;
                        border-radius: 14px;
                        padding: 1.5rem 1.2rem;
                        text-align: center;
                        box-shadow: 0 4px 12px rgba(93,64,55,0.1);
                        margin-bottom: 0.8rem;">
                <div style="font-size:2.8rem; margin-bottom:0.6rem;">👤</div>
                <p style="color:#3e2723; font-weight:700; margin:0; font-size:0.95rem;">{m['name']}</p>
                <p style="color:#8d6e63; font-size:0.82rem; margin:6px 0; font-weight:600;">{m['role']}</p>
                <p style="color:#6d4c41; font-size:0.78rem; margin:0;">{m['skills']}</p>
            </div>
            """, unsafe_allow_html=True)

    # ===== TECH STACK =====
    st.markdown('<h3 style="color:#4e342e; font-family:Playfair Display,serif; margin-top:1.5rem;">🛠️ Teknologi yang Digunakan</h3>', unsafe_allow_html=True)
    techs = [
        ("🐍", "Python", "Bahasa utama"),
        ("🌐", "Streamlit", "Web framework"),
        ("🤖", "Gemini API", "AI provider utama"),
        ("💡", "OpenAI API", "AI provider alternatif"),
        ("🔍", "FAISS", "Vector database"),
        ("🤗", "HuggingFace", "Sentence embeddings"),
        ("📄", "PyPDF2", "PDF processing"),
        ("🔧", "LangChain", "RAG pipeline"),
    ]
    cols = st.columns(4)
    for i, (icon, name, desc) in enumerate(techs):
        with cols[i % 4]:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                        border: 1px solid #d7ccc8;
                        border-radius: 12px;
                        padding: 1.1rem;
                        text-align: center;
                        margin-bottom: 0.8rem;
                        box-shadow: 0 3px 10px rgba(93,64,55,0.08);">
                <div style="font-size:1.8rem; margin-bottom:4px;">{icon}</div>
                <p style="color:#3e2723; font-weight:700; font-size:0.9rem; margin:4px 0;">{name}</p>
                <p style="color:#6d4c41; font-size:0.78rem; margin:0;">{desc}</p>
            </div>
            """, unsafe_allow_html=True)