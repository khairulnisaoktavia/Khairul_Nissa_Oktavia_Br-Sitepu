import streamlit as st

def show():
    st.markdown('<h2 class="main-title">📊 Progress Tracker</h2>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Pantau perkembangan belajarmu!</p>', unsafe_allow_html=True)

    history = st.session_state.get("quiz_history", [])

    if not history:
        st.info("📭 Belum ada data. Kerjakan quiz terlebih dahulu!")
        return

    total_quiz = len(history)
    avg_score = sum(h["score"] for h in history) / total_quiz
    best_score = max(h["score"] for h in history)

    col1, col2, col3 = st.columns(3)
    col1.metric("📝 Total Quiz", total_quiz)
    col2.metric("📈 Rata-rata Skor", f"{avg_score:.1f}%")
    col3.metric("🏆 Skor Terbaik", f"{best_score}%")

    st.markdown("---")
    st.markdown("### 📋 Riwayat Quiz")
    for i, h in enumerate(reversed(history)):
        color = "#10b981" if h["score"] >= 80 else "#f59e0b" if h["score"] >= 60 else "#ef4444"
        st.markdown(f"""
        <div style="background:#1e1b4b; border-left:4px solid {color}; border-radius:8px;
                    padding:0.8rem 1.2rem; margin-bottom:0.5rem; display:flex;
                    justify-content:space-between; align-items:center;">
            <span style="color:#cbd5e1;">Quiz #{total_quiz - i}</span>
            <span style="color:#94a3b8;">{h['correct']}/{h['total']} benar</span>
            <span style="color:{color}; font-weight:700; font-size:1.1rem;">{h['score']}%</span>
        </div>
        """, unsafe_allow_html=True)

    if st.button("🗑️ Reset Progress"):
        st.session_state.quiz_history = []
        st.rerun()