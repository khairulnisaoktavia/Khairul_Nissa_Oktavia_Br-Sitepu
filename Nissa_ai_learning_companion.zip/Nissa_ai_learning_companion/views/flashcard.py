import streamlit as st
import sys, os, json, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.ai_helper import get_ai_response, check_api_configured
from utils.styling import apply_styling

SYSTEM_PROMPT = """Buat flashcard dari materi yang diberikan. 
Output HANYA dalam format JSON valid seperti ini:
{
  "flashcards": [
    {"id": 1, "front": "Pertanyaan/Istilah", "back": "Jawaban/Definisi"}
  ]
}
Tanpa teks lain apapun."""

def parse_flashcards(text):
    text = re.sub(r"```json|```", "", text).strip()
    try:
        return json.loads(text).get("flashcards", [])
    except:
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group()).get("flashcards", [])
            except:
                pass
    return []

def show():
    apply_styling()

    st.markdown("""
    <style>
    /* Progress bar coklat */
    [data-testid="stProgressBar"] > div > div {
        background: linear-gradient(90deg, #5d4037, #8d6e63) !important;
    }
    [data-testid="stProgressBar"] {
        background: #e0cfc4 !important;
        border-radius: 10px !important;
    }
    /* Paksa semua teks dalam div HTML custom jadi krem */
    .flashcard-text p {
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<h2 style="font-family:Playfair Display,serif; background:linear-gradient(135deg,#3e2723,#8d6e63); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">🃏 Flashcard Generator</h2>', unsafe_allow_html=True)
    st.markdown('<p style="color:#6d4c41; font-size:1rem; margin-bottom:1.5rem;">Generate kartu hafalan otomatis dari materimu!</p>', unsafe_allow_html=True)

    if not check_api_configured():
        st.warning("⚠️ Harap masukkan API Key di sidebar terlebih dahulu.")
        return

    if "flashcards" not in st.session_state:
        st.session_state.flashcards = []
    if "card_index" not in st.session_state:
        st.session_state.card_index = 0
    if "show_answer" not in st.session_state:
        st.session_state.show_answer = False

    st.markdown('<h3 style="color:#4e342e;">📝 Input Materi</h3>', unsafe_allow_html=True)
    topic = st.text_input("Topik", placeholder="Contoh: Sistem Periodik Unsur, Hukum Newton")
    material = st.text_area("Materi / Teks (opsional)", height=150,
                            placeholder="Paste materi di sini, atau kosongkan dan AI akan generate dari topik.")
    num_cards = st.slider("Jumlah Flashcard", 5, 20, 10)

    if st.button("🃏 Generate Flashcards", use_container_width=True):
        if not topic:
            st.error("❌ Isi topik terlebih dahulu.")
            return
        prompt = f"""Buat {num_cards} flashcard untuk topik: {topic}
        {"Berdasarkan materi: " + material if material else ""}
        Output HANYA JSON."""
        with st.spinner("🃏 Membuat flashcard..."):
            raw = get_ai_response(prompt, SYSTEM_PROMPT)
        cards = parse_flashcards(raw)
        if cards:
            st.session_state.flashcards = cards
            st.session_state.card_index = 0
            st.session_state.show_answer = False
            st.rerun()
        else:
            st.error("❌ Gagal generate. Coba lagi.")

    if st.session_state.flashcards:
        cards = st.session_state.flashcards
        idx = st.session_state.card_index
        card = cards[idx]

        st.markdown("---")
        st.markdown(f'<p style="color:#4e342e; font-weight:600;">Kartu {idx+1} dari {len(cards)}</p>', unsafe_allow_html=True)
        st.progress((idx+1)/len(cards))

        if not st.session_state.show_answer:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #8d6e63, #6d4c41);
                        border-radius: 16px;
                        padding: 2.5rem;
                        text-align: center;
                        min-height: 180px;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        border: 1px solid #a1887f;
                        margin: 1rem 0;
                        box-shadow: 0 6px 20px rgba(93,64,55,0.3);">
                <p style="color:#fdf6ec !important; -webkit-text-fill-color:#fdf6ec !important;
                           font-size:0.8rem; margin:0 0 1rem 0;
                           text-transform:uppercase; letter-spacing:1.5px; font-weight:600;">
                    ❓ PERTANYAAN
                </p>
                <p style="color:#fdf6ec !important; -webkit-text-fill-color:#fff8e7 !important;
                           font-size:1.2rem; font-weight:600; margin:0; line-height:1.7;">
                    {card['front']}
                </p>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, #3e2723, #5d4037);
                        border-radius: 16px;
                        padding: 2.5rem;
                        text-align: center;
                        min-height: 180px;
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        border: 1px solid #8d6e63;
                        margin: 1rem 0;
                        box-shadow: 0 6px 20px rgba(62,39,35,0.4);">
                <p style="color:#fdf6ec !important; -webkit-text-fill-color:#fdf6ec !important;
                           font-size:0.8rem; margin:0 0 1rem 0;
                           text-transform:uppercase; letter-spacing:1.5px; font-weight:600;">
                    ✅ JAWABAN
                </p>
                <p style="color:#fdf6ec !important; -webkit-text-fill-color:#fff8e7 !important;
                           font-size:1.2rem; font-weight:600; margin:0; line-height:1.7;">
                    {card['back']}
                </p>
            </div>
            """, unsafe_allow_html=True)

        col1, col2, col3 = st.columns(3)
        with col1:
            if idx > 0:
                if st.button("⬅️ Sebelumnya", use_container_width=True):
                    st.session_state.card_index -= 1
                    st.session_state.show_answer = False
                    st.rerun()
        with col2:
            label = "👁️ Lihat Jawaban" if not st.session_state.show_answer else "🔄 Sembunyikan"
            if st.button(label, use_container_width=True):
                st.session_state.show_answer = not st.session_state.show_answer
                st.rerun()
        with col3:
            if idx < len(cards)-1:
                if st.button("➡️ Selanjutnya", use_container_width=True):
                    st.session_state.card_index += 1
                    st.session_state.show_answer = False
                    st.rerun()