import streamlit as st
import sys, os, json, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.ai_helper import get_ai_response, check_api_configured

SYSTEM_PROMPT = """Kamu adalah pembuat soal ujian yang ahli. Tugasmu adalah membuat soal pilihan ganda (MCQ) 
yang berkualitas tinggi, relevan, dan menguji pemahaman konsep dengan baik.

WAJIB output dalam format JSON yang valid seperti ini (tanpa markdown code block):
{
  "questions": [
    {
      "id": 1,
      "question": "Pertanyaan di sini?",
      "options": {
        "A": "Pilihan A",
        "B": "Pilihan B", 
        "C": "Pilihan C",
        "D": "Pilihan D"
      },
      "correct_answer": "A",
      "explanation": "Penjelasan mengapa jawaban ini benar."
    }
  ]
}

Pastikan:
- Hanya satu jawaban yang benar per soal
- Pengecoh (distractors) yang masuk akal dan tidak terlalu mudah ditebak
- Penjelasan yang jelas dan edukatif
- Output HANYA JSON, tanpa teks lain apapun
"""


def parse_quiz_json(text: str):
    """Extract and parse JSON from AI response."""
    # Remove possible markdown code blocks
    text = re.sub(r"```json|```", "", text).strip()
    try:
        data = json.loads(text)
        return data.get("questions", [])
    except json.JSONDecodeError:
        # Try to find JSON within text
        match = re.search(r'\{.*\}', text, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
                return data.get("questions", [])
            except:
                pass
    return []


def show():
    st.markdown('<h2 class="main-title">📝 Quiz Generator</h2>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Generate soal MCQ otomatis dan uji pemahamanmu!</p>', unsafe_allow_html=True)

    if not check_api_configured():
        st.warning("⚠️ Harap masukkan API Key di sidebar terlebih dahulu.")
        return

    # Quiz state management
    if "quiz_questions" not in st.session_state:
        st.session_state.quiz_questions = []
    if "quiz_answers" not in st.session_state:
        st.session_state.quiz_answers = {}
    if "quiz_submitted" not in st.session_state:
        st.session_state.quiz_submitted = False

    # === SETUP FORM ===
    if not st.session_state.quiz_questions:
        st.markdown("### ⚙️ Konfigurasi Quiz")

        col1, col2 = st.columns(2)
        with col1:
            topic = st.text_input(
                "📚 Topik / Materi",
                placeholder="Contoh: Hukum Newton, Fotosintesis, Persamaan Kuadrat"
            )
            num_questions = st.slider("🔢 Jumlah Soal", 3, 15, 5)

        with col2:
            difficulty = st.select_slider(
                "📊 Tingkat Kesulitan",
                options=["Mudah", "Sedang", "Sulit", "Campuran"],
                value="Sedang"
            )
            language = st.radio("🌐 Bahasa", ["Indonesia", "English"], horizontal=True)

        extra_context = st.text_area(
            "📋 Konteks Tambahan (opsional)",
            placeholder="Contoh: Fokus pada soal aplikasi, atau batasi pada bab tertentu saja.",
            height=80
        )

        if st.button("🎲 Generate Quiz", use_container_width=True):
            if not topic:
                st.error("❌ Mohon isi topik/materi terlebih dahulu.")
                return

            prompt = f"""
Buat {num_questions} soal pilihan ganda (MCQ) dengan kriteria:
- Topik: {topic}
- Tingkat kesulitan: {difficulty}
- Bahasa: {language}
- Konteks tambahan: {extra_context if extra_context else "Tidak ada"}

Buat soal yang menguji pemahaman konsep secara mendalam, bukan hanya hafalan.
Output HANYA dalam format JSON yang diminta, tanpa teks lain.
"""
            with st.spinner("🎲 AI sedang membuat soal..."):
                raw = get_ai_response(prompt, SYSTEM_PROMPT)

            questions = parse_quiz_json(raw)

            if questions:
                st.session_state.quiz_questions = questions
                st.session_state.quiz_answers = {}
                st.session_state.quiz_submitted = False
                st.rerun()
            else:
                st.error("❌ Gagal memparse soal. Coba lagi.")
                with st.expander("Debug: Raw AI Output"):
                    st.code(raw)

    # === QUIZ DISPLAY ===
    else:
        questions = st.session_state.quiz_questions

        if not st.session_state.quiz_submitted:
            st.markdown(f"### 📝 Quiz — {len(questions)} Soal")
            st.info("💡 Jawab semua soal lalu klik **Submit Quiz**.")

            for i, q in enumerate(questions):
                with st.container():
                    st.markdown(f"**Soal {i+1}.** {q['question']}")
                    options_list = [f"{k}. {v}" for k, v in q["options"].items()]
                    selected = st.radio(
                        f"Pilihan soal {i+1}",
                        options_list,
                        key=f"q_{q['id']}",
                        label_visibility="collapsed"
                    )
                    if selected:
                        st.session_state.quiz_answers[q["id"]] = selected[0]  # Save "A", "B", etc.
                    st.markdown("---")

            col1, col2 = st.columns(2)
            with col1:
                if st.button("✅ Submit Quiz", use_container_width=True):
                    if len(st.session_state.quiz_answers) < len(questions):
                        st.warning("⚠️ Jawab semua soal terlebih dahulu!")
                    else:
                        st.session_state.quiz_submitted = True
                        st.rerun()
            with col2:
                if st.button("🔄 Buat Quiz Baru", use_container_width=True):
                    st.session_state.quiz_questions = []
                    st.session_state.quiz_answers = {}
                    st.session_state.quiz_submitted = False
                    st.rerun()

        # === RESULTS ===
        else:
            correct = sum(
                1 for q in questions
                if st.session_state.quiz_answers.get(q["id"]) == q["correct_answer"]
            )
            total = len(questions)
            score = int((correct / total) * 100)
        
            # Score display
            if score >= 80:
                grade_color, grade_text = "#10b981", "🏆 Excellent!"
            elif score >= 60:
                grade_color, grade_text = "#f59e0b", "👍 Good Job!"
            else:
                grade_color, grade_text = "#ef4444", "📖 Perlu Belajar Lagi"
            

            st.markdown(f"""
            <div style="text-align:center; padding:2rem; background:linear-gradient(135deg,#1e1b4b,#1a1a2e); 
                        border-radius:16px; border:1px solid #312e81; margin-bottom:2rem;">
                <h2 style="color:{grade_color}; font-size:3rem; margin:0;">{score}%</h2>
                <p style="color:#e2e8f0; font-size:1.2rem; margin:0.5rem 0;">{grade_text}</p>
                <p style="color:#94a3b8;">Benar: {correct} / {total} soal</p>
            </div>
            """, unsafe_allow_html=True)

            # Review each question
            st.markdown("### 📋 Review Jawaban")
            for i, q in enumerate(questions):
                user_ans = st.session_state.quiz_answers.get(q["id"])
                is_correct = user_ans == q["correct_answer"]
                icon = "✅" if is_correct else "❌"
                bg = "rgba(16,185,129,0.1)" if is_correct else "rgba(239,68,68,0.1)"
                border = "#10b981" if is_correct else "#ef4444"

                st.markdown(f"""
                <div style="background:{bg}; border-left:4px solid {border}; border-radius:8px; 
                            padding:1rem 1.5rem; margin-bottom:1rem;">
                    <strong>{icon} Soal {i+1}:</strong> {q['question']}<br><br>
                    <span style="color:#94a3b8;">Jawabanmu: <strong>{user_ans}. {q['options'].get(user_ans,'')}</strong></span><br>
                    <span style="color:#10b981;">Jawaban benar: <strong>{q['correct_answer']}. {q['options'].get(q['correct_answer'],'')}</strong></span><br><br>
                    <span style="color:#cbd5e1;">💡 {q.get('explanation','')}</span>
                </div>
                """, unsafe_allow_html=True)

            st.markdown("---")
            col1, col2 = st.columns(2)
            with col1:
                if st.button("🔄 Coba Quiz Ini Lagi", use_container_width=True):
                    st.session_state.quiz_answers = {}
                    st.session_state.quiz_submitted = False
                    st.rerun()
            with col2:
                if st.button("🎲 Buat Quiz Baru", use_container_width=True):
                    st.session_state.quiz_questions = []
                    st.session_state.quiz_answers = {}
                    st.session_state.quiz_submitted = False
                    st.rerun()
