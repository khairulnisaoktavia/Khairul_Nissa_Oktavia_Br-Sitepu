import streamlit as st
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.ai_helper import get_ai_response, check_api_configured
from utils.styling import apply_styling

SYSTEM_PROMPT = """Kamu adalah asisten belajar yang ahli dalam menganalisis dokumen dan menjawab pertanyaan 
berdasarkan konten yang diberikan. 

Tugasmu:
1. Jawab pertanyaan HANYA berdasarkan konteks/dokumen yang diberikan
2. Jika informasi tidak ada dalam dokumen, katakan dengan jelas
3. Berikan jawaban yang terstruktur dengan referensi ke bagian dokumen yang relevan
4. Gunakan bullet points untuk poin-poin penting
5. Sertakan kutipan singkat dari dokumen jika relevan

Format jawaban:
- Jawaban langsung
- Poin-poin pendukung dari dokumen
- Sumber/bagian dokumen yang relevan
"""


def extract_text_from_pdf(pdf_file) -> str:
    try:
        import PyPDF2
        reader = PyPDF2.PdfReader(pdf_file)
        text = ""
        for i, page in enumerate(reader.pages):
            extracted = page.extract_text()
            if extracted:
                text += f"\n--- Halaman {i+1} ---\n{extracted}"
        return text.strip()
    except ImportError:
        return "ERROR: PyPDF2 tidak terinstall. Jalankan: pip install PyPDF2"
    except Exception as e:
        return f"ERROR: {str(e)}"


def build_faiss_index(text: str):
    try:
        from sentence_transformers import SentenceTransformer
        import faiss
        import numpy as np
        chunks = chunk_text(text, chunk_size=500, overlap=50)
        if not chunks:
            return None, None, None
        model = SentenceTransformer("all-MiniLM-L6-v2")
        embeddings = model.encode(chunks, show_progress_bar=False)
        embeddings = np.array(embeddings).astype("float32")
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings)
        return index, chunks, model
    except ImportError as e:
        return None, None, str(e)


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 50):
    words = text.split()
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i + chunk_size])
        chunks.append(chunk)
        i += chunk_size - overlap
    return chunks


def retrieve_relevant_chunks(query, index, chunks, model, top_k=3):
    try:
        import numpy as np
        query_embedding = model.encode([query])
        query_embedding = np.array(query_embedding).astype("float32")
        distances, indices = index.search(query_embedding, top_k)
        return [chunks[i] for i in indices[0] if i < len(chunks)]
    except:
        return []


def show():
    apply_styling()

    st.markdown("""
    <style>
    /* ===== FILE UPLOADER ===== */
    [data-testid="stFileUploader"],
    [data-testid="stFileUploader"] > div,
    [data-testid="stFileUploader"] > div > div,
    [data-testid="stFileUploader"] section,
    [data-testid="stFileUploaderDropzone"],
    [data-testid="stFileUploaderDropzone"] > div,
    div[class*="uploadedFile"],
    div[class*="fileUploader"] {
        background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9)) !important;
        background-color: rgba(255,248,240,0.95) !important;
        border-color: #a1887f !important;
        border-radius: 12px !important;
        width: 100% !important;
    }

    [data-testid="stFileUploader"] span,
    [data-testid="stFileUploader"] p,
    [data-testid="stFileUploader"] small,
    [data-testid="stFileUploader"] div {
        color: #4e342e !important;
        -webkit-text-fill-color: #4e342e !important;
    }

    [data-testid="stFileUploader"] button,
    [data-testid="stFileUploaderDropzone"] button {
        background: linear-gradient(135deg, #5d4037, #8d6e63) !important;
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
        border: none !important;
        border-radius: 10px !important;
        padding: 8px 20px !important;
    }

    [data-testid="stFileUploaderDropzone"] {
        min-height: 80px !important;
        padding: 1.2rem 1.5rem !important;
        display: flex !important;
        align-items: center !important;
        width: 100% !important;
        min-width: 100% !important;
        box-sizing: border-box !important;
    }

    [data-testid="stFileUploader"] {
        width: 100% !important;
        min-width: 100% !important;
    }

    [data-testid="stFileUploader"] > div {
        width: 100% !important;
        min-width: 100% !important;
    }
    </style>
    """, unsafe_allow_html=True)

    st.markdown('<h2 style="font-family:Playfair Display,serif; background:linear-gradient(135deg,#3e2723,#8d6e63); -webkit-background-clip:text; -webkit-text-fill-color:transparent;">📚 RAG Learning Assistant</h2>', unsafe_allow_html=True)
    st.markdown('<p style="color:#6d4c41; font-size:1rem; margin-bottom:1.5rem;">Upload dokumen PDF/catatan, lalu tanya apapun dari isinya!</p>', unsafe_allow_html=True)

    if not check_api_configured():
        st.warning("⚠️ Harap masukkan API Key di sidebar terlebih dahulu.")
        return

    rag_available = True
    try:
        import faiss
        from sentence_transformers import SentenceTransformer
    except ImportError:
        rag_available = False

    if not rag_available:
        st.markdown("""
        <div style="background:rgba(255,248,240,0.95); border-left:5px solid #8d6e63;
                    border-radius:12px; padding:1rem 1.5rem; margin-bottom:1rem;">
            <span style="color:#4e342e;">⚠️ <strong style="color:#3e2723;">Mode Terbatas:</strong> 
            Library FAISS / sentence-transformers belum terinstall.<br>
            Mode fallback aktif: menggunakan full document context tanpa vector search.<br>
            Untuk full RAG, jalankan: <code>pip install faiss-cpu sentence-transformers PyPDF2</code>
            </span>
        </div>
        """, unsafe_allow_html=True)

    for key, val in [("rag_text",""), ("rag_index",None), ("rag_chunks",None),
                     ("rag_model",None), ("rag_messages",[]), ("rag_filename","")]:
        if key not in st.session_state:
            st.session_state[key] = val

    # ===== UPLOAD SECTION =====
    st.markdown('<h3 style="color:#4e342e;">📤 Upload Dokumen</h3>', unsafe_allow_html=True)
    col1, col2 = st.columns([3, 1])

    with col1:
        upload_mode = st.radio("Mode Input", ["Upload PDF", "Paste Teks"], horizontal=True)

        if upload_mode == "Upload PDF":
            uploaded_file = st.file_uploader("Pilih file PDF", type=["pdf"])
            if uploaded_file and uploaded_file.name != st.session_state.rag_filename:
                with st.spinner("📖 Membaca PDF..."):
                    extracted = extract_text_from_pdf(uploaded_file)
                if extracted.startswith("ERROR"):
                    st.error(extracted)
                else:
                    st.session_state.rag_text = extracted
                    st.session_state.rag_filename = uploaded_file.name
                    st.session_state.rag_index = None
                    st.session_state.rag_messages = []
                    st.success(f"✅ PDF berhasil dimuat: {len(extracted.split())} kata")
        else:
            pasted_text = st.text_area(
                "Paste teks/catatan di sini",
                height=200,
                placeholder="Paste konten materi, catatan kuliah, atau teks apapun..."
            )
            if st.button("📥 Gunakan Teks Ini"):
                if pasted_text.strip():
                    st.session_state.rag_text = pasted_text
                    st.session_state.rag_filename = "pasted_text"
                    st.session_state.rag_index = None
                    st.session_state.rag_messages = []
                    st.success(f"✅ Teks dimuat: {len(pasted_text.split())} kata")

    with col2:
        if st.session_state.rag_text:
            word_count = len(st.session_state.rag_text.split())
            char_count = len(st.session_state.rag_text)
            st.metric("Jumlah Kata", f"{word_count:,}")
            st.metric("Jumlah Karakter", f"{char_count:,}")

            if rag_available and st.session_state.rag_index is None:
                if st.button("🔍 Build Vector Index (FAISS)", use_container_width=True):
                    with st.spinner("🔄 Membangun FAISS index..."):
                        idx, chunks, model = build_faiss_index(st.session_state.rag_text)
                    if idx is not None:
                        st.session_state.rag_index = idx
                        st.session_state.rag_chunks = chunks
                        st.session_state.rag_model = model
                        st.success(f"✅ Index dibuat: {len(chunks)} chunks")
                    else:
                        st.error(f"❌ Gagal: {model}")
            elif rag_available and st.session_state.rag_index is not None:
                st.success("✅ FAISS Index siap")
                chunk_count = len(st.session_state.rag_chunks) if st.session_state.rag_chunks else 0
                st.caption(f"{chunk_count} chunks diindeks")

    # ===== CHAT SECTION =====
    if st.session_state.rag_text:
        st.markdown("---")
        st.markdown('<h3 style="color:#4e342e;">💬 Tanya dari Dokumen</h3>', unsafe_allow_html=True)

        for msg in st.session_state.rag_messages:
            with st.chat_message(msg["role"], avatar="🧑‍🎓" if msg["role"] == "user" else "🤖"):
                st.markdown(msg["content"])

        user_q = st.chat_input("Tanyakan sesuatu dari dokumen ini...")

        if user_q:
            st.session_state.rag_messages.append({"role": "user", "content": user_q})
            with st.chat_message("user", avatar="🧑‍🎓"):
                st.markdown(user_q)

            with st.chat_message("assistant", avatar="🤖"):
                with st.spinner("🔍 Mencari informasi relevan..."):
                    if rag_available and st.session_state.rag_index is not None:
                        relevant_chunks = retrieve_relevant_chunks(
                            user_q, st.session_state.rag_index,
                            st.session_state.rag_chunks, st.session_state.rag_model, top_k=3
                        )
                        context = "\n\n---\n\n".join(relevant_chunks)
                        mode_label = "🔍 FAISS Vector Search"
                    else:
                        words = st.session_state.rag_text.split()
                        context = " ".join(words[:3000])
                        mode_label = "📄 Full Context Mode"

                    prompt = f"""Konteks dari dokumen:\n\"\"\"\n{context}\n\"\"\"\n\nPertanyaan: {user_q}\n\nJawab berdasarkan konteks dokumen di atas."""
                    response = get_ai_response(prompt, SYSTEM_PROMPT)

                st.caption(f"Mode: {mode_label}")
                st.markdown(response)
                st.session_state.rag_messages.append({"role": "assistant", "content": response})

        if st.session_state.rag_messages:
            st.markdown("---")
            col1, col2, col3 = st.columns([2, 1, 1])
            with col2:
                if st.button("🗑️ Hapus Chat"):
                    st.session_state.rag_messages = []
                    st.rerun()

    else:
        st.markdown("""
        <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                    border-left: 5px solid #8d6e63;
                    border-radius: 14px;
                    padding: 1.2rem 1.8rem;
                    margin-top: 1rem;
                    box-shadow: 0 4px 15px rgba(93,64,55,0.1);">
            <p style="color:#3e2723; font-weight:700; margin:0 0 0.6rem 0;">💡 Cara pakai:</p>
            <p style="color:#5d4037; margin:0.3rem 0;">1. Upload file PDF atau paste teks di atas</p>
            <p style="color:#5d4037; margin:0.3rem 0;">2. (Opsional) Build FAISS Index untuk pencarian yang lebih akurat</p>
            <p style="color:#5d4037; margin:0.3rem 0;">3. Mulai bertanya tentang isi dokumen!</p>
        </div>
        """, unsafe_allow_html=True)