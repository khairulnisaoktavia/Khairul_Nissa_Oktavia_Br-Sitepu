import streamlit as st
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.ai_helper import get_ai_response, check_api_configured

SYSTEM_PROMPT = """Kamu adalah konsultan pendidikan AI yang ahli dalam membuat rencana belajar yang terstruktur 
dan realistis. Tugasmu adalah membuat study plan yang detail, terorganisir, dan dapat dilaksanakan.

Format output wajib menggunakan struktur berikut:
1. Ringkasan rencana belajar (tujuan, durasi, intensitas)
2. Rencana harian yang detail dengan format:
   - Hari ke-X (Tanggal/Minggu)
   - Topik yang dipelajari
   - Aktivitas belajar spesifik (baca, latihan soal, review, dll)
   - Estimasi waktu
   - Target pencapaian
3. Tips dan strategi belajar yang relevan
4. Milestone mingguan untuk mengukur progress

Buat rencana yang realistis dan mempertimbangkan keseimbangan antara belajar dan istirahat.
"""


def show():
    st.markdown('<h2 class="main-title">📅 Study Plan Generator</h2>', unsafe_allow_html=True)
    st.markdown('<p class="sub-title">Buat rencana belajar personal yang terstruktur dan efektif.</p>', unsafe_allow_html=True)

    # ✅ CSS untuk mengubah dropdown multiselect menjadi coklat
    st.markdown("""
    <style>
    /* Container popup dropdown */
    div[data-baseweb="popover"] {
        background-color: #3E2010 !important;
    }

    /* List item dalam dropdown */
    div[data-baseweb="menu"] {
        background-color: #3E2010 !important;
    }

    div[data-baseweb="menu"] ul {
        background-color: #3E2010 !important;
        padding: 4px 0 !important;
    }

    div[data-baseweb="menu"] ul li {
        background-color: #3E2010 !important;
        color: #f5e6d3 !important;
    }

    div[data-baseweb="menu"] ul li:hover {
        background-color: #5C3317 !important;
        color: #ffffff !important;
        cursor: pointer;
    }

    /* Opsi yang sedang di-highlight/focus */
    div[data-baseweb="menu"] ul li[aria-selected="true"] {
        background-color: #5C3317 !important;
        color: #ffffff !important;
    }

    /* Popover wrapper */
    div[data-baseweb="popover"] > div {
        background-color: #3E2010 !important;
        border: 1px solid #7a4a2a !important;
        border-radius: 8px !important;
    }

    /* Scrollbar di dalam dropdown */
    div[data-baseweb="menu"] ul::-webkit-scrollbar {
        width: 6px;
    }
    div[data-baseweb="menu"] ul::-webkit-scrollbar-track {
        background: #3E2010;
    }
    div[data-baseweb="menu"] ul::-webkit-scrollbar-thumb {
        background-color: #7a4a2a;
        border-radius: 10px;
    }
    </style>
    """, unsafe_allow_html=True)

    if not check_api_configured():
        st.warning("⚠️ Harap masukkan API Key di sidebar terlebih dahulu.")
        return

    st.markdown("### 📋 Isi Detail Rencana Belajarmu")

    col1, col2 = st.columns(2)
    with col1:
        goal = st.text_area(
            "🎯 Tujuan Belajar",
            placeholder="Contoh: Menguasai materi Kalkulus untuk persiapan UAS, mencakup limit, turunan, dan integral.",
            height=120
        )
        subjects = st.text_area(
            "📚 Mata Pelajaran / Topik",
            placeholder="Contoh: Limit fungsi, Turunan, Aturan rantai, Integral tak tentu, Integral tertentu",
            height=100
        )

    with col2:
        duration_weeks = st.slider("⏱️ Durasi Belajar (minggu)", 1, 12, 4)
        hours_per_day = st.slider("🕐 Jam Belajar per Hari", 1, 8, 2)
        level = st.selectbox(
            "📊 Tingkat Kemampuan Saat Ini",
            ["Pemula (belum pernah belajar)", "Dasar (sedikit tahu)", 
             "Menengah (sudah paham dasar)", "Mahir (ingin memperdalam)"]
        )
        learning_style = st.multiselect(
            "🎨 Gaya Belajar",
            ["Membaca buku/modul", "Menonton video", "Latihan soal", 
             "Diskusi", "Membuat catatan/mind map", "Belajar dengan mengajar"],
            default=["Membaca buku/modul", "Latihan soal"]
        )

    target_exam = st.text_input(
        "🏆 Target / Ujian (opsional)",
        placeholder="Contoh: UAS Kalkulus tanggal 15 Juni, atau Ujian Masuk Perguruan Tinggi"
    )

    additional_notes = st.text_area(
        "📝 Catatan Tambahan (opsional)",
        placeholder="Contoh: Saya lemah di bagian integral substitusi, atau saya hanya bisa belajar di malam hari.",
        height=80
    )

    st.markdown("---")

    if st.button("🚀 Generate Study Plan", use_container_width=True):
        if not goal or not subjects:
            st.error("❌ Mohon isi Tujuan Belajar dan Mata Pelajaran/Topik terlebih dahulu.")
            return

        styles_text = ", ".join(learning_style) if learning_style else "fleksibel"

        prompt = f"""
Buatkan study plan yang detail dan terstruktur dengan informasi berikut:

**Tujuan Belajar:** {goal}
**Mata Pelajaran/Topik:** {subjects}
**Durasi:** {duration_weeks} minggu
**Jam belajar per hari:** {hours_per_day} jam/hari
**Tingkat kemampuan:** {level}
**Gaya belajar:** {styles_text}
**Target/Ujian:** {target_exam if target_exam else "Tidak ada target ujian spesifik"}
**Catatan tambahan:** {additional_notes if additional_notes else "Tidak ada"}

Buat rencana belajar harian yang lengkap, realistis, dan mudah diikuti. 
Pastikan mencakup semua topik secara bertahap dari mudah ke sulit.
"""

        with st.spinner("⏳ AI sedang membuat study plan untukmu..."):
            result = get_ai_response(prompt, SYSTEM_PROMPT)

        st.markdown("---")
        st.markdown("### 📅 Study Plan Kamu")
        st.markdown("""
        <div class="success-box">
        ✅ <strong>Study plan berhasil dibuat!</strong> Simpan atau print halaman ini untuk referensi belajarmu.
        </div>
        """, unsafe_allow_html=True)
        st.markdown(result)

        # Download button
        st.download_button(
            label="💾 Download Study Plan (.txt)",
            data=result,
            file_name="study_plan.txt",
            mime="text/plain"
        )