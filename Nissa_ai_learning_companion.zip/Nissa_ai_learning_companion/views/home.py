import streamlit as st
from utils.styling import apply_styling
import random

def show():
    apply_styling()

    st.markdown('<h1 class="main-title">Nissa AI Learning Companion 🎓</h1>', unsafe_allow_html=True)
    st.markdown('<p style="color:#6d4c41; font-size:1rem; margin-bottom:2rem;">Platform belajar cerdas berbasis AI untuk pengalaman belajar yang personal & adaptif.</p>', unsafe_allow_html=True)

    st.markdown("---")

    # ===== WELCOME BOX =====
    st.markdown("""
    <div style="background:linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.95));
                border-left: 5px solid #8d6e63;
                border-radius: 16px;
                padding: 1.5rem 2rem;
                margin-bottom: 1.5rem;
                box-shadow: 0 4px 15px rgba(93,64,55,0.1);">
        <strong style="color:#3e2723; font-size:1.05rem;">👋 Selamat Datang di Nissa AI Learning Companion!</strong><br><br>
        <span style="color:#4e342e; line-height:1.8;">
        Platform ini dirancang khusus untuk membantu kamu belajar lebih efektif, 
        efisien, dan menyenangkan dengan bantuan kecerdasan buatan. Tersedia berbagai 
        fitur unggulan seperti tanya jawab langsung dengan AI, pembuatan rencana belajar 
        personal, generator soal kuis interaktif, hingga asisten belajar berbasis dokumen.<br><br>
        Pilih fitur yang kamu butuhkan di sidebar sebelah kiri untuk mulai belajar! 🚀
        </span>
    </div>
    """, unsafe_allow_html=True)

    # ===== QUOTE HARI INI =====
    quotes = [
        "💡 \"Pendidikan adalah senjata paling ampuh yang bisa kamu gunakan untuk mengubah dunia.\" — Nelson Mandela",
        "🔥 \"Belajar tanpa berpikir adalah sia-sia, berpikir tanpa belajar adalah berbahaya.\" — Konfusius",
        "🚀 \"Investasi terbaik yang bisa kamu lakukan adalah investasi pada dirimu sendiri.\" — Warren Buffett",
        "🌟 \"Orang yang berhenti belajar adalah orang yang sudah tua, meski berumur 20 tahun.\" — Henry Ford",
        "📚 \"Semakin banyak kamu membaca, semakin banyak hal yang kamu ketahui.\" — Dr. Seuss",
        "✨ \"Kesuksesan adalah hasil dari persiapan, kerja keras, dan belajar dari kegagalan.\" — Colin Powell",
        "🎯 \"Jangan pernah berhenti belajar, karena hidup tidak pernah berhenti mengajarkan.\" — Unknown",
    ]

    st.markdown(f"""
    <div style="background: linear-gradient(135deg, #5d4037, #8d6e63);
                border-radius: 16px;
                padding: 1.5rem 2rem;
                margin-bottom: 2rem;
                box-shadow: 0 4px 15px rgba(93,64,55,0.3);">
        <p style="color:#fdf6ec; font-size:0.8rem; font-weight:700;
                  text-transform:uppercase; letter-spacing:1.5px; margin:0 0 0.6rem 0;">
            💬 QUOTE HARI INI
        </p>
        <p style="color:#f5e6d3; font-size:0.95rem; line-height:1.7; margin:0; font-style:italic;">
            {random.choice(quotes)}
        </p>
    </div>
    """, unsafe_allow_html=True)

    # ===== FITUR UTAMA =====
    st.markdown('<h3 style="color:#4e342e;">🚀 Fitur Utama</h3>', unsafe_allow_html=True)

    features = [
        {
            "icon": "💬",
            "title": "Ask Anything (Q&A)",
            "desc": "Tanyakan apapun tentang materi pelajaran. AI akan menjawab dengan penjelasan terstruktur dan mudah dipahami.",
            "badge": "Week 2"
        },
        {
            "icon": "📅",
            "title": "Personalized Study Plan",
            "desc": "Buat rencana belajar harian yang dipersonalisasi sesuai tujuan, timeline, dan mata pelajaran kamu.",
            "badge": "Week 3"
        },
        {
            "icon": "📝",
            "title": "Interactive Quiz Generator",
            "desc": "Generate soal MCQ otomatis dengan berbagai tingkat kesulitan untuk menguji pemahamanmu.",
            "badge": "Week 4"
        },
        {
            "icon": "📚",
            "title": "RAG Learning Assistant",
            "desc": "Upload dokumen PDF/catatan dan tanyakan pertanyaan spesifik dari konten dokumenmu menggunakan FAISS + HuggingFace.",
            "badge": "Week 5"
        },
    ]

    cols = st.columns(2)
    for i, f in enumerate(features):
        with cols[i % 2]:
            st.markdown(f"""
            <div style="background: linear-gradient(135deg, rgba(255,248,240,0.95), rgba(237,224,212,0.9));
                        border: 1px solid #d7ccc8;
                        border-radius: 16px;
                        padding: 1.5rem;
                        margin-bottom: 1rem;
                        box-shadow: 0 4px 15px rgba(93,64,55,0.1);
                        transition: all 0.3s ease;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:0.6rem;">
                    <span style="font-size:2rem;">{f['icon']}</span>
                    <span style="background:#8d6e63; color:#fdf6ec; padding:3px 12px;
                                 border-radius:20px; font-size:0.75rem; font-weight:600;">
                        {f['badge']}
                    </span>
                </div>
                <h4 style="color:#3e2723; margin:0 0 0.5rem 0; font-family:'Playfair Display',serif;">
                    {f['title']}
                </h4>
                <p style="color:#5d4037; font-size:0.88rem; line-height:1.6; margin:0;">
                    {f['desc']}
                </p>
            </div>
            """, unsafe_allow_html=True)

    st.markdown("---")

    # ===== CARA PENGGUNAAN =====
    st.markdown('<h3 style="color:#4e342e;">📋 Cara Penggunaan</h3>', unsafe_allow_html=True)
    steps = [
        ("⚙️", "Konfigurasi API Key", "Masukkan Gemini atau OpenAI API key di sidebar kiri."),
        ("🧭", "Pilih Fitur", "Navigasi ke fitur yang ingin digunakan via menu sidebar."),
        ("📝", "Input Data", "Isi form yang tersedia sesuai kebutuhan belajarmu."),
        ("🎯", "Dapatkan Hasil", "AI akan memproses dan memberikan hasil yang personal untukmu."),
    ]
    for i, (icon, title, desc) in enumerate(steps):
        st.markdown(f"""
        <div style="display:flex; align-items:flex-start; gap:1rem;
                    background: rgba(255,248,240,0.85);
                    border-radius: 12px;
                    padding: 1rem 1.2rem;
                    margin-bottom: 0.6rem;
                    border: 1px solid #e0cfc4;">
            <span style="background: linear-gradient(135deg, #5d4037, #8d6e63);
                          color:#fdf6ec; border-radius:50%; width:36px; height:36px;
                          display:flex; align-items:center; justify-content:center;
                          font-weight:700; font-size:0.9rem; flex-shrink:0;">{i+1}</span>
            <div>
                <strong style="color:#3e2723;">{icon} {title}</strong>
                <p style="color:#5d4037; margin:0.2rem 0 0 0; font-size:0.9rem;">{desc}</p>
            </div>
        </div>
        """, unsafe_allow_html=True)