# 🎓 AI Learning Companion
**Kelompok 3 — AI-Powered Smart Learning Companion for Personalized Education**

---

## 📋 Fitur

| Fitur | Deskripsi | Week |
|-------|-----------|------|
| 💬 Ask Anything | Q&A sistem berbasis Gemini/OpenAI | Week 2 |
| 📅 Study Plan Generator | Rencana belajar personal harian | Week 3 |
| 📝 Quiz Generator | Soal MCQ otomatis dengan review | Week 4 |
| 📚 RAG Assistant | Tanya dokumen PDF via FAISS + HuggingFace | Week 5 |

---

## 🚀 Cara Menjalankan

### 1. Clone / Download project ini

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Jalankan aplikasi
```bash
streamlit run app.py
```

### 4. Buka browser
Aplikasi akan berjalan di: `http://localhost:8501`

---

## 🔑 Konfigurasi API Key

Di sidebar aplikasi, pilih provider dan masukkan API Key:

- **Gemini API Key** → Dapatkan di: https://aistudio.google.com/app/apikey
- **OpenAI API Key** → Dapatkan di: https://platform.openai.com/api-keys

---

## 📁 Struktur Project

```
ai_learning_companion/
├── app.py                  # Entry point utama Streamlit
├── requirements.txt        # Daftar dependencies
├── README.md               # Dokumentasi ini
├── pages/
│   ├── home.py             # Halaman beranda
│   ├── qa.py               # Fitur Ask Anything (Q&A)
│   ├── study_plan.py       # Fitur Study Plan Generator
│   ├── quiz.py             # Fitur Quiz Generator
│   └── rag.py              # Fitur RAG Learning Assistant
└── utils/
    └── ai_helper.py        # Helper fungsi AI (Gemini & OpenAI)
```

---

## 🔧 Teknologi yang Digunakan

- **Frontend**: Streamlit
- **AI APIs**: Google Gemini API, OpenAI API
- **RAG**: FAISS (vector database) + HuggingFace Sentence Transformers
- **PDF Processing**: PyPDF2
- **Language**: Python 3.9+

---

## 📖 Cara Menggunakan Setiap Fitur

### 💬 Ask Anything
1. Pilih mata pelajaran (opsional)
2. Ketik pertanyaan di chat box
3. AI menjawab dengan format terstruktur

### 📅 Study Plan Generator
1. Isi tujuan belajar dan topik
2. Set durasi, jam belajar, dan level kemampuan
3. Klik "Generate Study Plan"
4. Download hasilnya

### 📝 Quiz Generator
1. Isi topik dan konfigurasi soal
2. Klik "Generate Quiz"
3. Jawab semua soal
4. Submit dan lihat hasil beserta penjelasan

### 📚 RAG Assistant
1. Upload PDF atau paste teks
2. (Opsional) Build FAISS Index untuk pencarian lebih akurat
3. Tanya tentang isi dokumen di chat box

---

## ⚠️ Catatan
- RAG dengan FAISS membutuhkan: `faiss-cpu` dan `sentence-transformers`
- Jika tidak terinstall, RAG tetap bisa digunakan dalam "Full Context Mode"
- Gunakan Python 3.9 - 3.11 untuk kompatibilitas terbaik
