import streamlit as st

def apply_styling():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Lato:wght@300;400;600&display=swap');

/* ===== FIX BAR HITAM BAWAH ===== */
.stBottomBlockContainer,
[data-testid="stBottomBlockContainer"],
div[class*="stBottomBlockContainer"] {
    background: linear-gradient(90deg, #3e2723, #5d4037) !important;
    border-top: 2px solid #a1887f !important;
}

/* Chat input di dalam bar bawah */
.stBottomBlockContainer .stChatInput,
[data-testid="stBottomBlockContainer"] .stChatInput,
[data-testid="stChatInput"] {
    background: transparent !important;
}

.stBottomBlockContainer textarea,
[data-testid="stBottomBlockContainer"] textarea,
[data-testid="stChatInputTextArea"] {
    background: rgba(255, 248, 240, 0.95) !important;
    color: #3e2723 !important;
    -webkit-text-fill-color: #3e2723 !important;
    border: 2px solid #a1887f !important;
    border-radius: 12px !important;
}

.stBottomBlockContainer textarea::placeholder,
[data-testid="stChatInputTextArea"]::placeholder {
    color: #a1887f !important;
    -webkit-text-fill-color: #a1887f !important;
}

/* Tombol send */
.stBottomBlockContainer button,
[data-testid="stBottomBlockContainer"] button {
    background: linear-gradient(135deg, #5d4037, #8d6e63) !important;
    border-color: #8d6e63 !important;
    color: #fdf6ec !important;
}

    /* ===== HEADER ATAS ===== */
    header[data-testid="stHeader"] {
        background: linear-gradient(90deg, #3e2723, #5d4037) !important;
        border-bottom: 2px solid #a1887f !important;
    }
    header[data-testid="stHeader"] * {
        color: #fdf6ec !important;
    }

    /* ===== HAPUS BAR HITAM BAWAH ===== */
    footer { display: none !important; }
    .stBottomBlockContainer {
        background: linear-gradient(90deg, #3e2723, #5d4037) !important;
        border-top: 2px solid #a1887f !important;
    }
    .stBottomBlockContainer * {
        color: #3e2723 !important;
    }
    .stChatInput textarea {
        background: rgba(255,248,240,0.95) !important;
        color: #3e2723 !important;
        border: 2px solid #a1887f !important;
        border-radius: 12px !important;
    }

    /* ===== BACKGROUND UTAMA ===== */
    .stApp {
        background: linear-gradient(135deg, #fdf6ec 0%, #f5e6d3 50%, #ede0d4 100%) !important;
        font-family: 'Lato', sans-serif;
    }

    /* ===== SIDEBAR BACKGROUND ===== */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #3e2723 0%, #5d4037 60%, #6d4c41 100%) !important;
        border-right: 3px solid #a1887f !important;
    }

    /* ===== SEMUA TEKS SIDEBAR → KREM ===== */
    section[data-testid="stSidebar"],
    section[data-testid="stSidebar"] p,
    section[data-testid="stSidebar"] span,
    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] div,
    section[data-testid="stSidebar"] h1,
    section[data-testid="stSidebar"] h2,
    section[data-testid="stSidebar"] h3,
    section[data-testid="stSidebar"] h4,
    section[data-testid="stSidebar"] small,
    section[data-testid="stSidebar"] .stMarkdown,
    section[data-testid="stSidebar"] .stMarkdown p {
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
    }

    /* ===== RADIO MENU SIDEBAR ===== */
    section[data-testid="stSidebar"] .stRadio > div {
        gap: 6px !important;
    }

    section[data-testid="stSidebar"] .stRadio > div > label {
        background: rgba(255,255,255,0.1) !important;
        border-radius: 10px !important;
        padding: 10px 14px !important;
        border: 1px solid rgba(255,255,255,0.15) !important;
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
        font-weight: 600 !important;
        font-size: 0.95rem !important;
        transition: all 0.25s ease !important;
        display: flex !important;
        align-items: center !important;
        width: 100% !important;
    }

    section[data-testid="stSidebar"] .stRadio > div > label:hover {
        background: rgba(255,255,255,0.22) !important;
        transform: translateX(4px) !important;
        border-color: #d7ccc8 !important;
    }

    /* Radio yang aktif/dipilih */
    section[data-testid="stSidebar"] .stRadio > div > label[data-baseweb="radio"] input:checked ~ div,
    section[data-testid="stSidebar"] .stRadio > div > label[aria-checked="true"] {
        background: rgba(255,255,255,0.28) !important;
        border-color: #fdf6ec !important;
    }

    /* Lingkaran radio */
    section[data-testid="stSidebar"] .stRadio input[type="radio"] + div {
        border-color: #fdf6ec !important;
    }
    section[data-testid="stSidebar"] .stRadio input[type="radio"]:checked + div {
        background-color: #fdf6ec !important;
        border-color: #fdf6ec !important;
    }

    /* ===== SELECTBOX SIDEBAR ===== */
    section[data-testid="stSidebar"] .stSelectbox > div > div {
        background: rgba(255,255,255,0.12) !important;
        border: 1px solid rgba(255,255,255,0.25) !important;
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
        border-radius: 10px !important;
    }

    /* ===== TEXT INPUT SIDEBAR (API Key) ===== */
    section[data-testid="stSidebar"] .stTextInput input {
        background: rgba(255,255,255,0.12) !important;
        border: 1px solid rgba(255,255,255,0.25) !important;
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
        border-radius: 10px !important;
    }
    section[data-testid="stSidebar"] .stTextInput input::placeholder {
        color: rgba(253,246,236,0.5) !important;
        -webkit-text-fill-color: rgba(253,246,236,0.5) !important;
    }

    /* ===== TOGGLE SIDEBAR ===== */
    section[data-testid="stSidebar"] .stToggle p,
    section[data-testid="stSidebar"] .stToggle span,
    section[data-testid="stSidebar"] .stToggle label {
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
    }

    /* ===== DIVIDER SIDEBAR ===== */
    section[data-testid="stSidebar"] hr {
        border-color: rgba(255,255,255,0.2) !important;
    }

    /* ===== SUCCESS BOX SIDEBAR ===== */
    section[data-testid="stSidebar"] .stAlert {
        background: rgba(255,255,255,0.1) !important;
        border-left: 3px solid #a5d6a7 !important;
    }
    section[data-testid="stSidebar"] .stAlert p {
        color: #c8e6c9 !important;
        -webkit-text-fill-color: #c8e6c9 !important;
    }

    /* ===== KONTEN UTAMA ===== */
    h1 {
        font-family: 'Playfair Display', serif !important;
        background: linear-gradient(135deg, #3e2723, #8d6e63, #a1887f);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-size: 2.8rem !important;
        font-weight: 700 !important;
    }
    h2, h3 {
        font-family: 'Playfair Display', serif !important;
        color: #4e342e !important;
        -webkit-text-fill-color: #4e342e !important;
    }
    p, li {
        color: #3e2723 !important;
        line-height: 1.8;
    }

    /* ===== TOMBOL ===== */
    .stButton > button {
        background: linear-gradient(135deg, #5d4037, #8d6e63) !important;
        color: #fdf6ec !important;
        -webkit-text-fill-color: #fdf6ec !important;
        border: none !important;
        border-radius: 25px !important;
        padding: 10px 28px !important;
        font-weight: 600 !important;
        transition: all 0.3s ease !important;
        box-shadow: 0 4px 15px rgba(93,64,55,0.3) !important;
    }
    .stButton > button:hover {
        background: linear-gradient(135deg, #4e342e, #6d4c41) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(93,64,55,0.45) !important;
    }

    /* ===== INPUT UTAMA ===== */
    .stTextInput > div > div > input,
    .stTextArea textarea {
        background: rgba(255,248,240,0.95) !important;
        border: 2px solid #d7ccc8 !important;
        border-radius: 12px !important;
        color: #3e2723 !important;
        -webkit-text-fill-color: #3e2723 !important;
    }
    .stTextInput > div > div > input:focus,
    .stTextArea textarea:focus {
        border-color: #8d6e63 !important;
        box-shadow: 0 0 0 3px rgba(141,110,99,0.2) !important;
    }

    /* ===== SELECTBOX UTAMA ===== */
    .stSelectbox > div > div {
        background: rgba(255,248,240,0.95) !important;
        border: 2px solid #d7ccc8 !important;
        border-radius: 12px !important;
        color: #3e2723 !important;
    }

    /* ===== MULTISELECT ===== */
    .stMultiSelect > div > div {
        background: rgba(255,248,240,0.95) !important;
        border: 2px solid #d7ccc8 !important;
        border-radius: 12px !important;
    }
    .stMultiSelect span[data-baseweb="tag"] {
        background: linear-gradient(135deg, #5d4037, #8d6e63) !important;
        color: #fdf6ec !important;
        border-radius: 20px !important;
    }

    /* ===== SLIDER ===== */
    .stSlider [data-baseweb="slider"] div[role="slider"] {
        background: #5d4037 !important;
        border-color: #5d4037 !important;
    }
    .stSlider [data-baseweb="slider"] div[data-testid="stTickBar"] {
        color: #8d6e63 !important;
    }

    /* ===== ALERT/INFO ===== */
    .stAlert {
        border-radius: 12px !important;
        border-left: 4px solid #8d6e63 !important;
        background: rgba(255,248,240,0.85) !important;
    }

    /* ===== METRIC ===== */
    [data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(255,248,240,0.9), rgba(237,224,212,0.9)) !important;
        border-radius: 16px !important;
        padding: 16px 20px !important;
        border: 1px solid #d7ccc8 !important;
        box-shadow: 0 4px 15px rgba(93,64,55,0.1) !important;
    }
    [data-testid="stMetricValue"] {
        color: #4e342e !important;
        -webkit-text-fill-color: #4e342e !important;
    }

    /* ===== CHAT MESSAGE ===== */
    [data-testid="stChatMessage"] {
        background: rgba(255,248,240,0.85) !important;
        border-radius: 16px !important;
        border: 1px solid #e0cfc4 !important;
        margin: 6px 0 !important;
    }

    /* ===== EXPANDER ===== */
    details summary {
        background: linear-gradient(135deg, rgba(255,248,240,0.9), rgba(237,224,212,0.9)) !important;
        border-radius: 12px !important;
        border: 1px solid #d7ccc8 !important;
        color: #4e342e !important;
        -webkit-text-fill-color: #4e342e !important;
        font-weight: 600 !important;
        padding: 10px 16px !important;
    }

    /* ===== SCROLLBAR ===== */
    ::-webkit-scrollbar { width: 6px; }
    ::-webkit-scrollbar-track { background: #fdf6ec; }
    ::-webkit-scrollbar-thumb {
        background: linear-gradient(#8d6e63, #5d4037);
        border-radius: 10px;
    }

    /* ===== HIDE DEFAULT NAV ===== */
    [data-testid="stSidebarNav"] { display: none !important; }

    </style>
    """, unsafe_allow_html=True)