import streamlit as st
import google.generativeai as genai
from openai import OpenAI


def get_ai_response(prompt: str, system_prompt: str = "") -> str:
    """
    Unified function to get AI response from either Gemini or OpenAI.
    Provider is determined by st.session_state["api_provider"].
    """
    provider = st.session_state.get("api_provider", "Gemini")

    if provider == "Gemini":
        return _gemini_response(prompt, system_prompt)
    else:
        return _openai_response(prompt, system_prompt)


def _gemini_response(prompt: str, system_prompt: str = "") -> str:
    api_key = st.session_state.get("gemini_api_key", "AQ.Ab8RN6IMw_-t6OGtJeZnmMirMGlh4BRkcBst3Q-FNgs1wInoLg")
    if not api_key:
        return "⚠️ Masukkan Gemini API Key terlebih dahulu di sidebar."

    try:
        genai.configure(api_key=api_key)
        model = genai.GenerativeModel(
            model_name="gemini-2.5-flash",
            system_instruction=system_prompt if system_prompt else None
        )
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"❌ Gemini Error: {str(e)}"


def _openai_response(prompt: str, system_prompt: str = "") -> str:
    api_key = st.session_state.get("openai_api_key", "AQ.Ab8RN6IMw_-t6OGtJeZnmMirMGlh4BRkcBst3Q-FNgs1wInoLg")
    if not api_key:
        return "⚠️ Masukkan OpenAI API Key terlebih dahulu di sidebar."

    try:
        client = OpenAI(api_key=api_key)
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.7,
            max_tokens=2048
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"❌ OpenAI Error: {str(e)}"


def check_api_configured() -> bool:
    """Returns True if the selected API key is configured."""
    provider = st.session_state.get("api_provider", "Gemini")
    if provider == "Gemini":
        return bool(st.session_state.get("gemini_api_key", "AQ.Ab8RN6IMw_-t6OGtJeZnmMirMGlh4BRkcBst3Q-FNgs1wInoLg"))
    else:
        return bool(st.session_state.get("openai_api_key", ""))
